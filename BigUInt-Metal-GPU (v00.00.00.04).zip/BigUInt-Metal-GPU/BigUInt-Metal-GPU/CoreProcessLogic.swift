//  CoreProcessLogic.swift
//  BigUInt-Metal-GPU
//  Created by SDBX on 10/4/2023.

import Foundation
import Metal

class MetalStuff {
    
    public static var metalDevice: MTLDevice? = MTLCopyAllDevices()[0];
    public static var commandQueue: MTLCommandQueue?
    public static var commandBuffers: [MTLCommandBuffer] = []
    public static var pipelineState: MTLComputePipelineState?
    
    static func printDevice() {
        print("Running on Device:", MetalStuff.metalDevice?.name ?? "Not set!")
    }
    
    static func initialize(pMetalDevice: Int) {
        MetalStuff.metalDevice = MTLCopyAllDevices()[pMetalDevice]
        
        MetalStuff.commandQueue = MetalStuff.metalDevice?.makeCommandQueue(maxCommandBufferCount: 2*GPU_THREAD_COUNT)
        MetalStuff.commandBuffers = Array(repeating: (MetalStuff.commandQueue?.makeCommandBuffer()!)!, count: GPU_THREAD_COUNT)

        let defaultLibrary = MetalStuff.metalDevice?.makeDefaultLibrary()
        let addKernelFunction = "add_arrays"
        let addKernel = (defaultLibrary?.makeFunction(name: addKernelFunction))!
        pipelineState = try! MetalStuff.metalDevice?.makeComputePipelineState(function: addKernel)
    }
}


class BigUInt {
    var value: [UInt32] // Array of 32-bit unsigned integers
        
    init(_ value: [UInt32]) {
        self.value = value
        self.value.insert(UInt32(value.count), at: 0) // Enhancement.
    }
    
    // Adds two BigUInts and returns the result
    func add(_ other: BigUInt, idxGCD: Int) -> BigUInt {
        
        let bufferSize = max(self.value.count, other.value.count) * 1;

        // let bufferSize = max(self.value.count, other.value.count) + 1
        let buffer1 = MetalStuff.metalDevice?.makeBuffer(bytes: self.value, length: bufferSize * MemoryLayout<UInt32>.size, options: [.storageModeManaged, .cpuCacheModeWriteCombined])!
        let buffer2 = MetalStuff.metalDevice?.makeBuffer(bytes: other.value, length: bufferSize * MemoryLayout<UInt32>.size, options: [.storageModeManaged, .cpuCacheModeWriteCombined])!
        
        // TODO: let result = [UInt32](repeating: 0, count: bufferSize + 0)

        // A buffer for individual results (zero initialized)
        let buffer3 = MetalStuff.metalDevice?.makeBuffer(length: MemoryLayout<UInt32>.stride * bufferSize, options: [])!
        // Our results in convenient form to compute the actual result later:
        let pointer = buffer3?.contents().bindMemory(to: UInt32.self, capacity: bufferSize)
        let results = UnsafeBufferPointer<UInt32>(start: pointer, count: bufferSize)
        
        // commandBuffers[idxGCD%THREAD_COUNT].waitUntilCompleted();
        MetalStuff.commandBuffers[idxGCD%GPU_THREAD_COUNT] = (MetalStuff.commandQueue?.makeCommandBuffer())!
        
        let commandEncoder: MTLComputeCommandEncoder? =  (MetalStuff.commandBuffers[idxGCD].makeComputeCommandEncoder(dispatchType: .concurrent))
        commandEncoder?.setComputePipelineState(MetalStuff.pipelineState!)
        commandEncoder?.setBuffer(buffer1, offset: 0, index: 0)
        commandEncoder?.setBuffer(buffer2, offset: 0, index: 1)
        commandEncoder?.setBuffer(buffer3, offset: 0, index: 2)

        let threadsPerGroup = MTLSize(width: 1024, height: 1, depth: 1)
        let numThreadgroups = MTLSize(width: 1, height: 1, depth: 1)
        commandEncoder?.dispatchThreadgroups(numThreadgroups, threadsPerThreadgroup: threadsPerGroup)

        commandEncoder?.endEncoding() // End the compute command encoder

        MetalStuff.commandBuffers[idxGCD].commit()
        MetalStuff.commandBuffers[idxGCD].waitUntilCompleted()

        // print(results)
        // WORKING OK, FOR NOW... [OK]: print(results.first!, results.last!)

        // return BigUInt(Array(results.drop(while: { $0 == 0 })))
        return BigUInt( [777] )
    }
}
