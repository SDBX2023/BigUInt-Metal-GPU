import Foundation
import Metal

let GPU_THREAD_COUNT    = 24576;


var GLOBAL_End_Encoding = false;

MetalStuff.initialize(pMetalDevice: 0)

print("Hello, World!")
MetalStuff.printDevice()

var testInputA: [UInt32] = Array(0x00...0xFF)
var testInputB: [UInt32] = Array(0x00...0xFF).reversed()

var bigGPUnumA: BigUInt = BigUInt(testInputA)
var bigGPUnumB: BigUInt = BigUInt(testInputB)

let benchmark = Date()

let semaphore = DispatchSemaphore(value: GPU_THREAD_COUNT)
for idxGCD in 0..<4096 { // 77555 {
    let idxGCDmod = idxGCD % GPU_THREAD_COUNT
    // print(idxGCD, idxGCDmod)
    semaphore.wait()
    DispatchQueue.global().async {
        _ = bigGPUnumA.add(bigGPUnumB, idxGCD: idxGCDmod)
        // ...
        semaphore.signal()
    }
}
// semaphore.wait()
let benchFinish = -benchmark.timeIntervalSinceNow * 1000;
print("Time Taken:", benchFinish, "ms.");

// print(bigGPUnumA, bigGPUnumA.value)
// print(bigGPUnumB, bigGPUnumB.value)
// print(rsltOutptC, rsltOutptC.value, rsltOutptC.value.count)

print("Goodbye.")
sleep(300);
